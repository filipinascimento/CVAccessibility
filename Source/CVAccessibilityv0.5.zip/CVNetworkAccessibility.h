//
//  CVNetworkAccessibility.h
//  CVNetwork
//
//  Created by Filipi Nascimento Silva on 8/27/13.
//  Copyright (c) 2013 Filipi Nascimento Silva. All rights reserved.
//

#ifndef CVNetwork_CVNetworkAccessibility_h
#define CVNetwork_CVNetworkAccessibility_h

#include "CVNetwork.h"
#include "CVBasicArrays.h"
#include "CVSimpleQueue.h"

CVBool CVNetworkCalculateAccessibility(const CVNetwork* network, CVFloatArray* accessibility, CVBool selfAvoided, CVIndex level,CVBool ballMeasurement,CVIntegerArray* accessedCount, CVOperationControl* operationControl);



#endif
